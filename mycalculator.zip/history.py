import tkinter as tk
from tkinter import ttk
import json
class HistoryWindow:
	def __init__(self, equation, flag):
		self.equation = equation
		self.flag = flag

		self.root = tk.Tk()	

		self.root.geometry('500x300')
		self.root.title('History Window')	

		self.back_button = ttk.Button(self.root, text='Back', command=self.print_selection)
		self.back_button.pack()	

		self.btnclear = ttk.Button(self.root, text = 'clear All History' ,  command = self.clearHistory  )
		self.btnclear.pack()

		self.frame = ttk.Frame(self.root)
		self.frame.pack()

	

		self.listHistory = tk.Listbox(self.frame, width=20, height=20, font=('Helvetica', 14))
		self.listHistory.bind('<<ListboxSelect>>', self.get_list)
		self.listHistory.pack(side='left', fill='y')

		self.read_History()

	def read_History(self):	
		f =open('history.txt')
		data =json.load(f)
		for detail in data['cal_details']:
			for i in detail:
				self.listHistory.insert('end',detail[i])		

		# f.close()
	def print_selection(self):
		if self.listHistory.curselection():
			value = self.listHistory.get(self.listHistory.curselection()) 
			self.equation.set(value.split('=')[1])
			self.flag.set(value.split('=')[1])
		self.root.destroy()
		
	  
	def get_list(self,event):
		index = self.listHistory.curselection()[0]
		seltext = self.listHistory.get(index)
		self.equation.set(seltext.split('=')[1])
		self.flag.set(seltext.split('=')[1])
		# self.listHistory.destroy()
		# self.root.destroy()
	def clearHistory(self):
		data = {"cal_details": []}
		with open('history.txt', 'w') as f:
			json.dump(data, f)
		self.listHistory.delete(0, 'end')

			
		 


