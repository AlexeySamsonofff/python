import tkinter as tk
from tkinter import ttk
from history import HistoryWindow
import json


exp = " "
rowtxt =" "
count = 0
def press(num):
    global exp
    flagval =flag.get()
    if flagval:
        exp =flagval + str(num)
        flag.set("")
    else:
        exp+=str(num)  
    equation.set(exp)

def equalpress():
    try:
        global exp
        global count
        total = str(eval(exp))
        equation.set(total)
        rowtxt = exp + "=" + total
        exp = " "
        
        save_json(count,rowtxt)
        count += 1
    except:
        equation.set('error')
        exp = " "
def write_json(data, filename='history.txt'):    
    with open(filename, 'w') as f:
      json.dump(data, f)

def save_json(count,rowtxt): 

    cal_details = {
        "details": rowtxt
        } 
    if count ==0:
        data = {"cal_details": [{"details": rowtxt },]}

    else:
        with open('history.txt') as f: 
            data = json.load(f) 
            temp = data['cal_details']
            temp.append(cal_details)

    write_json(data)  
    


def clear ():
    global exp
    exp = " "
    equation.set(" ")
    flag.set("")

def onHistory():
    listHistory = HistoryWindow(equation, flag)
    listHistory.root.mainloop()

# def clearHistory():
#     data = {"cal_details": []}
#     write_json(data)



if __name__ == "__main__":


    dk = tk.Tk()
    dk.title('Calculator')
    # dk.geometry('300x220')
    # dk.maxsize(width=300,height=220)

    # dk.configure(bg='blue')



equation = tk.StringVar()
dis_entry = ttk.Entry(dk, state = 'readonly', background ='red', textvariable = equation)
dis_entry.grid(row = 0 , columnspan = 4)
dis_entry.focus()

flag = tk.StringVar()
hidden_grid = ttk.Entry(dk, state = 'readonly',  textvariable = flag)
hidden_grid .grid_remove()




#1
btn1 = ttk.Button(dk, text = '1' ,  command = lambda : press(1)  )
btn1.grid(row = 1 , column = 0 )


btn2 = ttk.Button(dk, text = '2' ,  command = lambda : press(2)  )
btn2.grid(row = 1 , column = 1 )


btn3 = ttk.Button(dk, text = '3' ,  command = lambda : press(3) )
btn3.grid(row = 1 , column = 2)

btnplus = ttk.Button(dk, text = '+' ,  command = lambda : press("+") )
btnplus.grid(row = 1 , column = 3)


#2
btn4 = ttk.Button(dk, text = '4' ,  command = lambda : press(4) )
btn4.grid(row = 2 , column = 0)

btn5 = ttk.Button(dk, text = '5' ,  command = lambda : press(5) )
btn5.grid(row = 2 , column = 1 )

btn6 = ttk.Button(dk, text = '6' ,   command = lambda : press(6) )
btn6.grid(row = 2 , column = 2)

btnmines = ttk.Button(dk, text = '-' ,  command = lambda : press('-') )
btnmines.grid(row = 2 , column = 3 )

#3
btn7 = ttk.Button(dk, text = '7' ,   command = lambda : press(7) )
btn7.grid(row = 3 , column = 0 )

btn8 = ttk.Button(dk, text = '8' ,  command = lambda : press(8) )
btn8.grid(row = 3 , column = 1 )

btn9 = ttk.Button(dk, text = '9' , command = lambda : press(9) )
btn9.grid(row = 3 , column = 2)



btnmul = ttk.Button(dk, text = '*' ,  command = lambda : press("*") )
btnmul.grid(row = 3 , column = 3 )

#4
btn0 = ttk.Button(dk, text = '0' ,   command = lambda : press(0) )
btn0.grid(row = 4 , column = 0)

btnequal = ttk.Button(dk, text = '=' ,  command = equalpress )
btnequal.grid(row = 4 , column = 1)

btnclr = ttk.Button(dk, text = 'C' , command = clear )
btnclr.grid(row = 4 , column = 2)


btndiv = ttk.Button(dk, text = '/' ,  command = lambda : press("/")  )
btndiv.grid(row = 4 , column = 3)


#5
btnhistory = ttk.Button(dk, text = 'Calculator History' ,   command = onHistory )
btnhistory.grid(row = 5 , column=0, columnspan = 4)

# btnclear = ttk.Button(dk, text = 'clear History' ,  command = clearHistory  )
# btnclear.grid(row = 5 , column = 3 )



dk.mainloop()